# modelo_latex_teses
Universidade Federal de Uberlândia
Faculdade de Engenharia Elétrica
Laboratório de Engenharia Biomédica
######################################################################
Repositório com modelo em LaTeX para a escrita das teses e dissertações
